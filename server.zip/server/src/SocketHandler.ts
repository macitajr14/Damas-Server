import { Server, Socket } from 'socket.io';
import { GameRoom } from './GameRoom.js';
import { Move } from './types.js';

const rooms = new Map<string, GameRoom>();
const socketToRoom = new Map<string, string>();

export function setupSocketHandlers(io: Server) {
    io.on('connection', (socket: Socket) => {
        console.log(`✅ Client connected: ${socket.id}`);

        // Create room
        socket.on('createRoom', (playerName: string, callback: (roomId: string) => void) => {
            const roomId = generateRoomId();
            const room = new GameRoom(roomId, playerName, socket.id);

            rooms.set(roomId, room);
            socketToRoom.set(socket.id, roomId);

            socket.join(roomId);

            console.log(`🎮 Room created: ${roomId} by ${playerName}`);

            callback(roomId);
            socket.emit('gameState', room.gameState);

            // Broadcast updated room list to all connected clients
            io.emit('waitingRoomsUpdate', getWaitingRoomsList());
        });

        // Get waiting rooms
        socket.on('getWaitingRooms', (callback: (rooms: any[]) => void) => {
            callback(getWaitingRoomsList());
        });

        // Join room
        socket.on('joinRoom', (roomId: string, playerName: string, callback: (success: boolean, state?: any) => void) => {
            const room = rooms.get(roomId);

            if (!room) {
                console.log(`❌ Room not found: ${roomId}`);
                callback(false);
                return;
            }

            if (room.players.size >= 2) {
                console.log(`❌ Room full: ${roomId}`);
                callback(false);
                return;
            }

            const success = room.addPlayer(socket.id, playerName);

            if (success) {
                socketToRoom.set(socket.id, roomId);
                socket.join(roomId);

                console.log(`👥 ${playerName} joined room: ${roomId}`);

                // Notify both players
                io.to(roomId).emit('gameState', room.gameState);
                socket.to(roomId).emit('playerJoined', {
                    id: socket.id,
                    name: playerName,
                    color: 'red',
                });

                // Broadcast updated room list (room is now full)
                io.emit('waitingRoomsUpdate', getWaitingRoomsList());

                callback(true, room.gameState);
            } else {
                callback(false);
            }
        });

        // Make move
        socket.on('makeMove', (move: Move) => {
            const roomId = socketToRoom.get(socket.id);
            if (!roomId) return;

            const room = rooms.get(roomId);
            if (!room) return;

            try {
                const newState = room.applyMove(move);

                console.log(`🎯 Move made in room ${roomId}`);

                // Broadcast new state to all players in room
                io.to(roomId).emit('gameState', newState);

                // Check for game over
                if (newState.winner) {
                    io.to(roomId).emit('gameOver', newState.winner);
                }
            } catch (error) {
                console.error('Error applying move:', error);
                socket.emit('error', 'Invalid move');
            }
        });

        // Leave room
        socket.on('leaveRoom', () => {
            handleDisconnect(socket, io);
        });

        // Send quick chat message
        socket.on('sendChat', (message: string) => {
            const roomId = socketToRoom.get(socket.id);
            if (!roomId) return;

            const room = rooms.get(roomId);
            if (!room) return;

            const player = room.players.get(socket.id);
            if (!player) return;

            // Broadcast to all players in room
            io.to(roomId).emit('chatMessage', {
                playerName: player.name,
                message,
                timestamp: Date.now(),
            });
        });

        // Request rematch
        socket.on('requestRematch', () => {
            const roomId = socketToRoom.get(socket.id);
            if (!roomId) return;

            const room = rooms.get(roomId);
            if (!room) return;

            // Create new game state
            const players = Array.from(room.players.values());
            const newRoom = new GameRoom(roomId, players[0].name, players[0].id);

            if (players.length === 2) {
                newRoom.addPlayer(players[1].id, players[1].name);
            }

            rooms.set(roomId, newRoom);

            io.to(roomId).emit('gameState', newRoom.gameState);
            console.log(`🔄 Rematch started in room ${roomId}`);
        });

        // Disconnect
        socket.on('disconnect', () => {
            console.log(`❌ Client disconnected: ${socket.id}`);
            handleDisconnect(socket, io);
        });
    });
}

function handleDisconnect(socket: Socket, io: Server) {
    const roomId = socketToRoom.get(socket.id);

    if (roomId) {
        const room = rooms.get(roomId);

        if (room) {
            room.removePlayer(socket.id);

            // Notify other players
            socket.to(roomId).emit('playerLeft', socket.id);

            // If room is empty, delete it
            if (room.players.size === 0) {
                rooms.delete(roomId);
                console.log(`🗑️  Room deleted: ${roomId}`);
            }

            // Broadcast updated room list to all clients
            io.emit('waitingRoomsUpdate', getWaitingRoomsList());
        }

        socketToRoom.delete(socket.id);
    }
}

function generateRoomId(): string {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
}

function getWaitingRoomsList(): { roomId: string; hostName: string; createdAt: number }[] {
    const waitingRooms: { roomId: string; hostName: string; createdAt: number }[] = [];

    rooms.forEach((room, roomId) => {
        // Only include rooms with 1 player (waiting for opponent)
        if (room.players.size === 1) {
            const host = Array.from(room.players.values())[0];
            waitingRooms.push({
                roomId,
                hostName: host.name,
                createdAt: Date.now(), // Could store actual creation time in GameRoom
            });
        }
    });

    return waitingRooms;
}

