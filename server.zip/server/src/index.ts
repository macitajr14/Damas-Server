import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import { setupSocketHandlers } from './SocketHandler.js';

const app = express();
const httpServer = createServer(app);

// Configure CORS
const clientUrl = process.env.CLIENT_URL || 'http://localhost:3000';

app.use(cors({
    origin: clientUrl,
    credentials: true,
}));

// Create Socket.io server
const io = new Server(httpServer, {
    cors: {
        origin: clientUrl,
        methods: ['GET', 'POST'],
        credentials: true,
    },
});

// Setup socket event handlers
setupSocketHandlers(io);

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

const PORT = process.env.PORT || 3001;

httpServer.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
    console.log(`🎮 Socket.io server ready for connections`);
});
