// Copy types from client for server use
export type PieceColor = 'red' | 'black';
export type PieceType = 'normal' | 'king';

export interface Position {
    row: number;
    col: number;
}

export interface Piece {
    id: string;
    color: PieceColor;
    type: PieceType;
    position: Position;
}

export interface Move {
    from: Position;
    to: Position;
    capturedPieces?: Position[];
}

export interface ValidMove {
    to: Position;
    captures: Position[];
    isJump: boolean;
}

export type GameStatus = 'waiting' | 'playing' | 'finished';
export type GameMode = 'bot' | 'local' | 'online';

export interface Player {
    id: string;
    name: string;
    color: PieceColor;
    isBot?: boolean;
}

export interface GameState {
    id: string;
    mode: GameMode;
    status: GameStatus;
    board: (Piece | null)[][];
    currentTurn: PieceColor;
    players: Player[];
    winner?: PieceColor;
    selectedPiece?: Position;
    validMoves: ValidMove[];
    moveHistory: Move[];
    mustCapture: boolean;
}
