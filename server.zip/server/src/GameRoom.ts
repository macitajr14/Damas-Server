import { GameState, Player, Move, PieceColor } from './types.js';

export class GameRoom {
    public id: string;
    public gameState: GameState;
    public players: Map<string, Player>;
    public createdAt: Date;

    constructor(roomId: string, creatorName: string, creatorSocketId: string) {
        this.id = roomId;
        this.createdAt = new Date();
        this.players = new Map();

        // Creator is always black (goes first)
        const creator: Player = {
            id: creatorSocketId,
            name: creatorName,
            color: 'black',
        };

        this.players.set(creatorSocketId, creator);

        // Initialize game state
        this.gameState = this.createInitialState([creator]);
    }

    addPlayer(socketId: string, playerName: string): boolean {
        if (this.players.size >= 2) {
            return false; // Room is full
        }

        const player: Player = {
            id: socketId,
            name: playerName,
            color: 'red', // Second player is always red
        };

        this.players.set(socketId, player);

        // Update game state with both players
        this.gameState = this.createInitialState(Array.from(this.players.values()));
        this.gameState.status = 'playing';

        return true;
    }

    removePlayer(socketId: string): void {
        this.players.delete(socketId);
    }

    applyMove(move: Move): GameState {
        const newBoard = this.copyBoard(this.gameState.board);
        const piece = newBoard[move.from.row][move.from.col];

        if (!piece) {
            throw new Error('No piece at source position');
        }

        // Move the piece
        newBoard[move.to.row][move.to.col] = {
            ...piece,
            position: move.to,
        };
        newBoard[move.from.row][move.from.col] = null;

        // Remove captured pieces
        if (move.capturedPieces) {
            move.capturedPieces.forEach(pos => {
                newBoard[pos.row][pos.col] = null;
            });
        }

        // Check for king promotion
        if (this.shouldPromoteToKing(piece, move.to)) {
            newBoard[move.to.row][move.to.col]!.type = 'king';
        }

        // Switch turn
        const nextTurn: PieceColor = this.gameState.currentTurn === 'black' ? 'red' : 'black';

        // Check if next player must capture
        const mustCapture = this.hasCapturingMoves(newBoard, nextTurn);

        // Check for winner
        const winner = this.checkWinner(newBoard, nextTurn, mustCapture);

        this.gameState = {
            ...this.gameState,
            board: newBoard,
            currentTurn: nextTurn,
            moveHistory: [...this.gameState.moveHistory, move],
            mustCapture,
            winner,
            status: winner ? 'finished' : 'playing',
            selectedPiece: undefined,
            validMoves: [],
        };

        return this.gameState;
    }

    private createInitialState(players: Player[]): GameState {
        return {
            id: this.id,
            mode: 'online',
            status: players.length === 2 ? 'playing' : 'waiting',
            board: this.createInitialBoard(),
            currentTurn: 'black',
            players,
            validMoves: [],
            moveHistory: [],
            mustCapture: false,
        };
    }

    private createInitialBoard() {
        const board: any[][] = Array(8).fill(null).map(() => Array(8).fill(null));

        // Place black pieces (top 3 rows)
        for (let row = 0; row < 3; row++) {
            for (let col = 0; col < 8; col++) {
                if ((row + col) % 2 === 1) {
                    board[row][col] = {
                        id: `black-${row}-${col}`,
                        color: 'black',
                        type: 'normal',
                        position: { row, col },
                    };
                }
            }
        }

        // Place red pieces (bottom 3 rows)
        for (let row = 5; row < 8; row++) {
            for (let col = 0; col < 8; col++) {
                if ((row + col) % 2 === 1) {
                    board[row][col] = {
                        id: `red-${row}-${col}`,
                        color: 'red',
                        type: 'normal',
                        position: { row, col },
                    };
                }
            }
        }

        return board;
    }

    private shouldPromoteToKing(piece: any, position: any): boolean {
        if (piece.type === 'king') return false;
        if (piece.color === 'black' && position.row === 7) return true;
        if (piece.color === 'red' && position.row === 0) return true;
        return false;
    }

    private hasCapturingMoves(board: any[][], color: PieceColor): boolean {
        for (let row = 0; row < 8; row++) {
            for (let col = 0; col < 8; col++) {
                const piece = board[row][col];
                if (piece && piece.color === color) {
                    const directions: [number, number][] = [[-1, -1], [-1, 1], [1, -1], [1, 1]];

                    for (const [dRow, dCol] of directions) {
                        if (piece.type === 'king') {
                            // Flying king: can capture from any distance
                            let distance = 1;
                            while (true) {
                                const checkRow = row + dRow * distance;
                                const checkCol = col + dCol * distance;

                                if (checkRow < 0 || checkRow >= 8 || checkCol < 0 || checkCol >= 8) break;

                                const checkPiece = board[checkRow][checkCol];
                                if (checkPiece) {
                                    if (checkPiece.color !== color) {
                                        // Found enemy - check if landing square exists
                                        const landRow = checkRow + dRow;
                                        const landCol = checkCol + dCol;
                                        if (landRow >= 0 && landRow < 8 && landCol >= 0 && landCol < 8 && !board[landRow][landCol]) {
                                            return true;
                                        }
                                    }
                                    break; // Hit a piece, stop
                                }
                                distance++;
                            }
                        } else {
                            // Normal piece: check if this direction is valid for the piece color
                            // Black moves down (positive row), Red moves up (negative row)
                            const validDirection = piece.color === 'black' ? dRow > 0 : dRow < 0;
                            if (!validDirection) continue;

                            const jumpRow = row + dRow * 2;
                            const jumpCol = col + dCol * 2;
                            const overRow = row + dRow;
                            const overCol = col + dCol;

                            if (jumpRow >= 0 && jumpRow < 8 && jumpCol >= 0 && jumpCol < 8) {
                                const overPiece = board[overRow][overCol];
                                const jumpSquare = board[jumpRow][jumpCol];

                                if (overPiece && overPiece.color !== color && !jumpSquare) {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    private checkWinner(board: any[][], currentTurn: PieceColor, mustCapture: boolean): PieceColor | undefined {
        let blackPieces = 0;
        let redPieces = 0;

        for (let row = 0; row < 8; row++) {
            for (let col = 0; col < 8; col++) {
                const piece = board[row][col];
                if (piece) {
                    if (piece.color === 'black') blackPieces++;
                    if (piece.color === 'red') redPieces++;
                }
            }
        }

        if (blackPieces === 0) return 'red';
        if (redPieces === 0) return 'black';

        return undefined;
    }

    private copyBoard(board: any[][]): any[][] {
        return board.map(row => row.map(piece => piece ? { ...piece } : null));
    }
}
